package dxg;

import java.util.*;
import java.nio.*;

public class FileHeader {
	// 0x0, signature 'DXG'
	byte[] signature;

	// 0x4, 1 fixed (flag A1)
	short flag_a1;

	// 0x6, (5,6,7) (flag A2)
	short flag_a2;

	// 0x8, use from bit0 to bit5 (mostly 3,7,39) (flag A3)
	// - bit 0: mesh data present
	// - bit 1: ancillary data a0 or a1 present
	// - bit 2: has ancillary data b
	// - bit 3: ancillary data c present
	// - bit 4: always 0
	// - bit 5: has ancillary data d
	short flag_a3;

	// 0xa, 0 fixed (flag A4)
	short flag_a4;

	// 0xc, number of mesh data
	int nr_groups;

	// 0x10, offset to aux_data
	// = aux_data start position - 20
	int next_data_offset;

	// 0x14, size of mesh name list
	int group_names_size;

	// 0x18, mesh name list
	String[] group_names;

	FileHeader(ByteBuffer bf, ArrayList<Span> ranges) {
		Span span = new Span("File Header", bf.position(), -1, 1, -1);
		ranges.add(span);

		signature = new byte[4];
		for (int i = 0; i < 4; i++)
			signature[i] = bf.get();
		flag_a1 = bf.getShort();
		flag_a2 = bf.getShort();
		flag_a3 = bf.getShort();
		flag_a4 = bf.getShort();
		nr_groups = bf.getInt();
		next_data_offset = bf.getInt();
		group_names_size = bf.getInt();
		group_names = Util.getNames(bf, group_names_size);
		span.setLength(bf.position() - span.start);
	}

	void show(int what) {
		System.out.printf("file header\n");
		switch (what) {
			case Dxg.SIZES:
				System.out.printf("nr_groups: %d\n", nr_groups);
				break;

			case Dxg.OFFSETS:
				System.out.printf(" next_data_offset: %d\n", next_data_offset);
				break;

			case Dxg.FLAGS:
				if (flag_a1 != 1)
					System.out.printf(" flag_a1: %d\n", flag_a1);
				System.out.printf(" flag_a2: %d\n", flag_a2);
				int x = flag_a3;
				System.out.printf(" flag_a3: [%d,%d,%d,%d,%d,%d], %d\n",
						(x >> 5) & 1, (x >> 4) & 1, (x >> 3) & 1,
						(x >> 2) & 1, (x >> 1) & 1, (x >> 0) & 1, x);
				if (flag_a4 != 0)
					System.out.printf(" flag_a4: %d\n", flag_a4);
				break;

			case Dxg.NAMES:
				System.out.printf("group_names: %s\n", Util.join(group_names));
				break;
		}
	}
}