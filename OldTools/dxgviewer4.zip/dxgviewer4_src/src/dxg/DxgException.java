package dxg;

public class DxgException extends Exception {
    public DxgException(String msg) {
	super(msg);
    }

    public DxgException(String msg, Throwable th) {
	super(msg, th);
    }
}
