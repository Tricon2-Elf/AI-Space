package dxg;

import java.util.*;
import java.nio.*;

public class MeshData {
	MeshHeader mesh_header;

	// vertex_info: Decompose and store in the following fields.
	int[] vertex_lut; // int[vertex_info_nr]
	int[] normal_lut; // int[vertex_info_nr]
	int[] uv_lut; // int[vertex_info_nr]

	// face_info: 3 elements corresponding to the face_info structure.
	short[] face_info; // short[face_info_nr * 3]

	String[] nameT;
	byte[] dataU;

	MeshData(ByteBuffer bf, int nr, ArrayList<Span> ranges) {
		int i, n;
		Span span = new Span("mesh" + nr, bf.position(), -1, 1, -1);
		ranges.add(span);

		// read mesh header
		mesh_header = new MeshHeader(bf, ranges);

		// read vertex information
		n = mesh_header.vertex_info_nr;
		ranges.add(new Span(" vertex information", bf.position(), n * 5 * 2, n, 5 * 2));
		vertex_lut = new int[n];
		normal_lut = new int[n];
		uv_lut = new int[n];
		for (i = 0; i < n; i++) {
			vertex_lut[i] = bf.getShort();
			normal_lut[i] = bf.getShort();
			uv_lut[i] = bf.getShort();
			bf.getShort(); // discard
			bf.getShort(); // discard
		}

		// read surface information
		n = mesh_header.face_info_nr;
		ranges.add(new Span("Surface Information", bf.position(), n * 3 * 2, n, 3 * 2));
		face_info = new short[n * 3];
		for (i = 0; i < n * 3; i++)
			face_info[i] = bf.getShort();

		// name T
		if (mesh_header.name_t_nr == 0) {
			nameT = new String[0];
		} else {
			n = bf.getInt();
			ranges.add(new Span("NameT", bf.position() - 4, 4 + n, 4 + n, 1));
			nameT = Util.getNames(bf, n);
		}

		// data U
		n = (mesh_header.data_u_nr + 3) / 4 * 4;
		ranges.add(new Span("DataU", bf.position(), n, 1, n));
		bf.position(bf.position() + n);

		span.setLength(bf.position() - span.start);
	}
}