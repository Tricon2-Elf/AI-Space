package dxg;

import java.util.*;
import java.nio.*;

public class AuxB {
    int nr_aux_elems;
    String[] names;
    // TODO: Socket information
    // Socket[] sockets;

    AuxB(ByteBuffer bf, String type, FileHeader fhdr, ArrayList<Span> ranges) {
    }

    void show(int what) {
    }
}
