package dxg;

import java.util.*;
import java.nio.*;

public class MeshHeader {
	// 0x24, number of vertex information
	short vertex_info_nr;

	// 0x26, number of surface information
	short face_info_nr;

	// 0x28, number of names in name list T
	int name_t_nr;

	// 0x2c, number of data U
	int data_u_nr;

	// 0x30, offset of vertex coordinates
	// = vertex coordinate position - mesh info position - 52
	int vertices_offset;

	MeshHeader(ByteBuffer bf, ArrayList<Span> ranges) {
		ranges.add(new Span(" mesh header",
				bf.position(), 0x10, 1, 0x10));
		vertex_info_nr = bf.getShort();
		face_info_nr = bf.getShort();
		name_t_nr = bf.getInt();
		data_u_nr = bf.getInt();
		verteces_offset = bf.getInt();
	}

	void show(int what) {
		switch (what) {
			case Dxg.SIZES:
				System.out.printf(" vertex_info_nr: %d\n", vertex_info_nr);
				System.out.printf("face_info_nr: %d\n", face_info_nr);
				System.out.printf(" name_t_nr: %d\n", name_t_nr);
				System.out.printf(" data_u_nr: %d\n", data_u_nr);
				break;

			case Dxg.OFFSETS:
				System.out.printf(" verteces_offset: %d\n", verteces_offset);
				break;
		}
	}
}