package dxg;

public class BoneLink {
    // bone number
    short index;
    // parent bone number. 255 without parents
    short parent;
    // First child bone number. 255 if no children
    short child;
    // The number of the next sibling bone. 255 without siblings
    short siblings;
}