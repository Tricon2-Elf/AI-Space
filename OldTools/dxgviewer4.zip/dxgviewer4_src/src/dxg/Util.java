package dxg;

import java.util.ArrayList;
import java.io.*;
import java.nio.*;

class Util {

	static final String CES = "Shift_JIS";

	static String[] getNames(ByteBuffer bf, int length) {
		byte[] raw = new byte[length];
		bf.get(raw);

		ArrayList<String> r = new ArrayList<String>();
		int start = 0;
		int i;

		try {
			for (;;) {
				if (start >= length) {
					break;
				}
				if (raw[start] == 0) {
					break;
				}
				for (i = start; i < length; i++) {
					if (raw[i] == 0) {
						break;
					}
				}
				r.add(new String(raw, start, i - start, CES));
				start = i + 1;
			}
		} catch (UnsupportedEncodingException e) {
			throw new RuntimeException(e);
		}
		return r.toArray(new String[0]);
	}

	static String join(String[] a) {
		StringBuffer sb = new StringBuffer();
		for (int i = 0; i < a.length; i++) {
			sb.append(a[i]);
			if (i < a.length - 1) {
				sb.append(", ");
			}
		}
		return sb.toString();
	}
}
