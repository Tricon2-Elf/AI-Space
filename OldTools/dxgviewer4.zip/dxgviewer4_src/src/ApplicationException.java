class ApplicationException extends Exception {
    ApplicationException(String msg) {
	super(msg);
    }

    ApplicationException(String msg, Throwable th) {
	super(msg, th);
    }
}
