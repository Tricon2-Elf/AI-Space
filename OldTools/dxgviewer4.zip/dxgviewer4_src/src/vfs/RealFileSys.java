package vfs;

import java.io.*;
import java.nio.*;
import java.nio.channels.*;

/**
 * �¥ե����륷���ƥ�
 */
class RealFileSys extends Vfs {
    private File mBaseDir;

    RealFileSys(String basePath) throws IOException {
	mBaseDir = new File(basePath);
	if(!mBaseDir.isDirectory())
	    throw new RuntimeException(basePath + " is not directory");
    }

    public ByteBuffer getBuffer(String relPath) throws IOException {
	File file = new File(mBaseDir, relPath.replace('\\', '/'));
	FileChannel fc = new FileInputStream(file).getChannel();
	ByteBuffer buf = null;
	try {
	    buf = fc.map(FileChannel.MapMode.READ_ONLY, 0, (int)fc.size());
	} catch(Exception e) {
	    buf = ByteBuffer.allocate((int)fc.size());
	    fc.read(buf);
	}
	buf.order(ByteOrder.LITTLE_ENDIAN);
	return buf;
    }
}
