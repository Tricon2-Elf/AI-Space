package vra;

import java.util.regex.*;

/**
 * vra�Ρ��ɤ�°����ɽ�魯���饹
 */
public class Attr {
    private final static Pattern ATTR_REGEX = Pattern.compile
	("\\s*\\((\\w+)\\s+(\\w+)\\[(\\d+)\\]\\s+(.*)\\)");
    private final static Pattern COMMA_REGEX = Pattern.compile("\\s*,\\s*");

    private final static boolean DEBUG = false;

    private final String mName;
    private final String mType;
    private final Object[] mValues;

    /**
     * ���󥹥ȥ饯��.
     * �ե�������ͤΤ����ꡣ
     * VraAttr���饹�ϥե����ȥ�᥽�åɰʳ��Ǥϥ��󥹥��󥹤���ʤ���
     */
    private Attr(String name, String type, Object[] values) {
	mName = name;
	mType = type;
	mValues = values;
    }

    public String getName() {
	return mName;
    }

    public String getType() {
	return mType;
    }

    public Object[] getValues() {
	return mValues;
    }

    //----------------------------------------------------------------------

    /**
     * °����ɽ�魯ʸ���󤫤�VraAttr���֥������Ȥ�������롣
     */
    public static Attr parse(String s) throws VraException {
	// �ޤ�������ɽ���˥ޥå�������
	Matcher m = ATTR_REGEX.matcher(s);
	if(!m.matches())
	    throw new VraException("illegal format: invalid input: " + s);
	String name = m.group(1);
	String baseType = m.group(2);
	int nrVectors = Integer.valueOf(m.group(3));
	int nrScalars = nrVectors;
	if(baseType.equals("vector3"))
	    nrScalars = nrVectors * 3;
	else if(baseType.equals("quat"))
	    nrScalars = nrVectors * 4;
	if(DEBUG)
	    System.out.printf("  attr: %s -> (%s %s[%d] %s)\n",
			      s, name, baseType, nrScalars, m.group(4));

	// ����ޤ�ʬΥ
	String[] args = COMMA_REGEX.split(m.group(4), nrScalars);
	Object[] values = new Object[nrScalars];
	if(DEBUG)
	    for(int i = 0; i < args.length; i++)
		System.out.printf("  attr: args[%d]=%s\n", i, args[i]);

	// �ͤ򤽤줾��η�������
	if(baseType.equals("int32")
	   || baseType.equals("int16")
	   || baseType.equals("int8")) {
	    for(int i = 0; i < nrScalars; i++)
		values[i] = new Integer(Integer.valueOf(args[i]));
	} else if(baseType.equals("float")
		  || baseType.equals("vector3")
		  || baseType.equals("quat")) {
	    for(int i = 0; i < nrScalars; i++)
		values[i] = new Float(Float.valueOf(args[i]));
	} else if(baseType.equals("string")) {
	    for(int i = 0; i < nrScalars; i++)
		values[i] = args[i].substring(1, args[i].length() - 1);
	} else {
	    throw new VraException("illegal format: unknown type: " + baseType);
	}

	return new Attr(name, baseType, values);
    }

}
