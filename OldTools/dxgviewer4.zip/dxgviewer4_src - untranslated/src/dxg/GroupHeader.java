package dxg;

import java.util.*;
import java.nio.*;

public class GroupHeader {
    // 0x00, 1���� (�ե饰B1)
    int flag_b1;

    // 0x04, group_data��ü�ؤΥ��ե��å�
    // = ��ü - ��ü - 8
    int offset_f1;

    // 0x08, 0���� (�ե饰B2)
    int flag_b2;

    // 0x0c, ��å���ǡ�����? (�ե饰B3)
    // flag_b3 & 0xffff0000 == 0
    // flag_b3 & 0xff00 == 0xff00
    // flag_b3 & 0xff == ��å���ǡ�����
    int flag_b3;

    // 0x10, offset_f - 28
    int offset_g;

    // 0x14, ĺ����ɸ�ο�
    short verteces_nr;

    // 0x16, ˡ���٥��ȥ�ο�
    short normals_nr;

    // 0x18, UV��ɸ�ο�
    int uv_nr;

    // 0x1c, �ǡ���V�ο�
    int data_v_nr;

    // 0x20, �������ȥޥåפο�
    int weight_map_nr;

    GroupHeader(ByteBuffer bf, ArrayList<Span> ranges) {
	ranges.add(new Span("  ���롼�ץإå�", bf.position(), 0x24, 1, 0x24));
	flag_b1 = bf.getInt();
	offset_f1 = bf.getInt();
	flag_b2 = bf.getInt();
	flag_b3 = bf.getInt();
	offset_g = bf.getInt();
	verteces_nr = bf.getShort();
	normals_nr = bf.getShort();
	uv_nr = bf.getInt();
	data_v_nr = bf.getInt();
	weight_map_nr = bf.getInt();
    }

    void show(int what) {
	switch(what) {
	case Dxg.SIZES:
	    System.out.printf("  nr_meshes: %d\n", flag_b3 & 255);
	    System.out.printf("  verteces_nr: %d\n", verteces_nr);
	    System.out.printf("  normals_nr: %d\n", normals_nr);
	    System.out.printf("  uv_nr: %d\n", uv_nr);
	    System.out.printf("  data_v_nr: %d\n", data_v_nr);
	    System.out.printf("  weight_map_nr: %d\n", weight_map_nr);
	    break;

	case Dxg.OFFSETS:
	    System.out.printf("  offset_f1: %d\n", offset_f1);
	    System.out.printf("  offset_g: %d\n", offset_g);
	    break;

	case Dxg.FLAGS:
	    if(flag_b1 != 1)
		System.out.printf("  flag_b1: %d\n", flag_b1);
	    if(flag_b2 != 0)
		System.out.printf("  flag_b2: %d\n", flag_b2);
	    break;
	}
    }
}
