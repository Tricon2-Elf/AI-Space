
public class HedEnviron {
    public String dataDir;
    public String decodedDir;

    public HedEnviron() {
	dataDir = "data";
	decodedDir = "unpacked";
    }
};
