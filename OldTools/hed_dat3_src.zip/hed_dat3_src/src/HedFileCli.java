import java.io.*;

public class HedFileCli extends HedFile {

    public HedFileCli(File dataDir, File decodedDir) {
	super(dataDir, decodedDir);
    }

    public HedFileCli(File dataDir, File decodedDir, File hedFile) throws IOException {
	super(dataDir, decodedDir, hedFile);
    }

    protected void loadedMember(HedMember member) {
	// ���о��������ɤ����Ȥ��˸ƤФ��᥽�å�
    }

    protected void extractedMember(HedMember member) {
	// ���Хե������Ÿ���������˸ƤФ��᥽�å�
	System.out.println("extracted " + member.mFile.getPath());
    }
    protected void storedMember(HedMember member) {
	// ���Хե�������Ǽ�����Ȥ��˸ƤФ��᥽�å�
	System.out.println("stored " + member.mFile.getPath());
    }


    //----------------------------------------------------------------------

    static void printHelp() {
	System.out.println("Usage:");
	System.out.println("\tlist hed_file data_dir");
	System.out.println("\textract hed_file data_dir work_dir");
	System.out.println("\tbuild hed_file data_dir work_dir");
    }

    static void list(String hedPath,
		     String dataDirPath) throws IOException {
	HedFileCli hed = new HedFileCli(new File(dataDirPath),
					null,
					new File(hedPath));
	for(int j = 0; j < hed.mMembers.size(); j++) {
	    HedMember item = hed.mMembers.get(j);
	    System.out.printf("%d%8d%8d %d %s %s\n",
			      item.mDatIndex, item.mFileOffset,
			      item.mMemberSize, item.mUpdatedTime,
			      item.mPath1, item.mPath2);
	}
    }
    
    static void extract(String hedPath,
			String dataDirPath, String unpackedDirPath)
	throws IOException {
	HedFileCli hed = new HedFileCli(new File(dataDirPath),
					new File(unpackedDirPath),
					new File(hedPath));
	File dataDir = new File(dataDirPath);
	File unpackedDir = new File(unpackedDirPath);
	hed.extractAll();
    }

    static void build(String hedPath,
		      String dataDirPath, String unpackedDirPath)
	throws IOException{
	HedFileCli hed = new HedFileCli(new File(dataDirPath),
					new File(unpackedDirPath),
					new File(hedPath));
	File dataDir = new File(dataDirPath);
	File unpackedDir = new File(unpackedDirPath);
	hed.storeAll();
    }

    public static void main(String argv[]) {
	if(argv.length == 0) {
	    printHelp();
	    return;
	}

	try {
	    if(argv[0].equals("list") && argv.length >= 3) {
		list(argv[1], argv[2]);
	    } else if(argv[0].equals("extract") && argv.length >= 4) {
		extract(argv[1], argv[2], argv[3]);
	    } else if(argv[0].equals("build") && argv.length >= 4) {
		build(argv[1], argv[2], argv[3]);
	    } else {
		printHelp();
	    }
	} catch (Exception e) {
	    System.err.println("Error: exception occured");
	    e.printStackTrace();
	}
    }
}
