import java.io.*;
import java.util.*;
import java.util.regex.*;
import java.util.logging.*;

/**
 * ����ǥ��쥯�ȥ�ʲ��ˤ��ꡢ�������������ɽ���˥ޥå�����ե������
 * õ��FileFinder���饹
 */
public class RegexFileFinder extends FileFinder {
    private Pattern mMatchPtn;
    private Pattern[] mSkipPtns;

    private static Logger logger = Logger.getLogger("RegexFileFinder");

    //----------------------------------------------------------------------

    /**
     * @param pattern	�ޥå�����������ɽ��
     */
    public RegexFileFinder(Pattern matchPtn, Pattern[] skipPtns) {
	mMatchPtn = matchPtn;
	mSkipPtns = skipPtns;
    }

    public RegexFileFinder(Pattern matchPtn) {
	this(matchPtn, new Pattern[0]);
    }

    private static boolean isSymLink(File f) {
	return false;
    }

    boolean filter(File f) {
	// �ե�����Ǥ��ꡢ���Ļ��ꤵ�줿����ɽ���ȥޥå�����Ȥ�
	if(f.isFile()) {
	    Matcher m = mMatchPtn.matcher(f.getPath());
	    if(m.matches()) {
		logger.fine("passed: " + f.getPath());
		return true;
	    }
	}
	logger.fine("skipped: " + f.getPath());
	return false;
    }

    boolean prune(File f) {
	// ����ܥ�å���󥯤�é��ʤ�
	if(isSymLink(f)) {
	    logger.fine("pruned(symlink): " + f.getPath());
	    return true;
	}
	for(int i = 0; i < mSkipPtns.length; i++) {
	    if(mSkipPtns[i].matcher(f.getPath()).matches()) {
		logger.fine("pruned(regexp): " + f.getPath());
		return true;
	    }
	}
	return false;
    }

    //----------------------------------------------------------------------

    public static void main(String argv[]) {
	if(argv.length < 2)
	    return;

	Pattern matchPtn = Pattern.compile(argv[1]);
	Pattern[] skipPtns = new Pattern[argv.length - 2];
	for(int argc = 2; argc < argv.length; argc++)
	    skipPtns[argc - 2] = Pattern.compile(argv[argc]);

	RegexFileFinder rff = new RegexFileFinder(matchPtn, skipPtns);
	File[] array = rff.find(new File(argv[0])).getArray();
	for(int i = 0; i < array.length; i++)
	    System.out.println(array[i].getPath());
    }
}
